package com.example.pokedex;

import com.example.codesamples.JSONExample;
import com.example.codesamples.SQLiteExample;

public class Main {
    public static void main(String[] args) throws Exception {
        PokedexRunner runner = new PokedexRunner();
        runner.start();
    }
}
