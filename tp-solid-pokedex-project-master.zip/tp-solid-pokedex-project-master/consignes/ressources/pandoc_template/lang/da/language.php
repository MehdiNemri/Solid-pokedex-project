<?php

$LANG = array();

